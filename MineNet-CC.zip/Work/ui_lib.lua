-- ui_lib.lua
UI = {
    elements = {},
    width = 0,
    height = 0
}
BLOCK_DB = {}

local MAX_X = 100
local MAX_Y = 100
local MAX_Z = 100

function UI.init(monitor)
  UI.monitor = monitor
  UI.width, UI.height = monitor.getSize()
  monitor.setTextScale(0.5)
  UI.clear()
end

function UI.clear()
  local m = UI.monitor
  m.setBackgroundColor(colors.black)
  m.clear()
end

function UI.drawText(x, y, text, textColor, bgColor)
  local m = UI.monitor
  m.setTextColor(textColor or colors.white)
  m.setBackgroundColor(bgColor or colors.black)
  m.setCursorPos(x, y)
  m.write(text)
end

function UI.drawButton(id, x, y, w, h, label, textColor, bgColor, onClick)
  local m = UI.monitor
  local btn = {
    id = id, type = "button", x = x, y = y, w = w, h = h,
    label = label, textColor = textColor or colors.white,
    bgColor = bgColor or colors.gray, onClick = onClick
  }
  table.insert(UI.elements, btn)

  m.setBackgroundColor(btn.bgColor)
  for i = 0, h - 1 do
    m.setCursorPos(x, y + i)
    m.write((" "):rep(w))
  end

  m.setCursorPos(x + math.floor((w - #label) / 2), y + math.floor(h / 2))
  m.setTextColor(btn.textColor)
  m.write(label)
end

function UI.drawGrid(x, y, cols, rows, cellW, cellH, gridFunc)
  local m = UI.monitor
  for row = 1, rows do
    for col = 1, cols do
      local cellX = x + (col - 1) * cellW
      local cellY = y + (row - 1) * cellH
      local color = gridFunc(col, row)
      m.setBackgroundColor(color)
      for h = 0, cellH - 1 do
        m.setCursorPos(cellX, cellY + h)
        m.write((" "):rep(cellW))
      end
    end
  end
end

--NEW
function UI.initBlockDB() 
  for layers = 1, MAX_Y do
    BLOCK_DB[layers] = {}
    for col = 1, MAX_X do
      BLOCK_DB[layers][col] = {}  -- or a default value like false or "empty"
        for row = 1, MAX_Z do
              BLOCK_DB[layers][col][row] = colors.gray
            end
        end
    end
end

--NEW
--Note changeGridColor changes the database not the screen
function UI.changeGridColor(col, row, layer, color)
    if BLOCK_DB[layer] and BLOCK_DB[layer][col] and BLOCK_DB[layer][col][row] then
        BLOCK_DB[layer][col][row] = color
    end
end
--NEW
function UI.ResetTurtlePos()
  for layer, cols in pairs(BLOCK_DB) do
    for col, rows in pairs(cols) do
        for row =1, #rows do
            -- Example condition: check if the color is "yellow"
            if rows[row] == colors.yellow then
                BLOCK_DB[layer][col][row] = colors.black
            end
        end
    end
  end
end
--NEW
function UI.CheckDB(layer,UI_X,UI_Y)
  selectedLayer = {}
  UI.drawGrid(2, 2, 55, 35, 1, 1, function(col, row)

    local dbX = UI_X + col - 1
    local dbZ = UI_Y + row - 1

    if BLOCK_DB[layer] and BLOCK_DB[layer][dbX] and BLOCK_DB[layer][dbX][dbZ] then
      selectedLayer = BLOCK_DB[layer][dbX][dbZ] 
    else 
      selectedLayer = colors.red -- only if empty for some reason
    end
    return selectedLayer
  end)
end
--NEW
function UI.SaveDB()
  UI.ResetTurtlePos()
  file = fs.open("BLOCK_DB.txt", "w")
  file.write(textutils.serialize(BLOCK_DB))
  file.close()
end
--NEW
function UI.GetSavedDB()
  local exist = fs.exists("BLOCK_DB.txt")
  if (exist)then
      file = fs.open("BLOCK_DB.txt", "r")
      local content = file.readAll()
      pack = textutils.unserialize(content)
      BLOCK_DB = pack
  else
      print("No Saved DB available")
  end
end
--NEW
function UI.getCurrentGridTurtles(pack)
  if (type(pack) == "table")then
    for key, value in pairs(pack) do
      local X = value[1].x
      local Z = value[1].z
      local Y = value[1].y
      UI.changeGridColor(X,Z,Y, colors.yellow)
    end
  else 
    MineNet.logToFile(textutils.serialize({a={}}), 'nope')
  end
end
--NEW
function UI.getLastGridTurtles(pack)
  MineNet.logToFile(textutils.serialize(pack), 'val')
  
  if (type(pack) == "table")then
    for key, value in pairs(pack) do
      MineNet.logToFile(textutils.serialize(value[1]), 'val2')
      local X = value[1].x
      local Z = value[1].z
      local Y = value[1].y
      UI.changeGridColor(X,Z,Y, colors.black)
    end
  else 
    MineNet.logToFile(textutils.serialize({a={}}), 'nope2')
  end
end
--NEW 
function UI.drawBox(x, y, w, h, bgColor, label,monitor)
    for dy = 0, h - 1 do
      monitor.setCursorPos(x, y + dy)
      monitor.setBackgroundColor(bgColor)
      monitor.write((" "):rep(w))
    end
    -- Center the label
    local labelX = x + math.floor((w - #label) / 2)
    local labelY = y + math.floor(h / 2)
    UI.drawText(labelX, labelY, label, textColor, bgColor)
  end
function UI.handleTouch(x, y)
  for _, el in ipairs(UI.elements) do
    if el.type == "button" then
      if x >= el.x and x <= el.x + el.w - 1 and y >= el.y and y <= el.y + el.h - 1 then
        if el.onClick then el.onClick() end
        break
      end
    end
  end
end